# ResearchV2 (with Patched Runner)
리서치V2 정교화 리포 뼈대입니다.  
- 엔트리/데이터 계약, 경로/글롭 정규화
- 지표 보강기(`ci/metrics_enforcer.py`): **gross + net(CAGR)** 산출
- 민감도 벡터/컴페어2 워크플로(SHA pinned)
- 시작자본 $1,000 / position_fraction / fee/slip bps 파라미터화
- **패치 러너**: `backtest/runner_patched.py`

## 사용법
1) 새 GitHub 리포 생성 후 이 폴더 전체 업로드.
2) 루트에 추가:
   - `strategy_v2_codepack_v2.1.3.zip`
   - `ETHUSDT_1min_2020_2025.zip` (있으면 워크플로가 자동 unzip)
3) Actions 실행:
   - **Compare Two Singles - enforce metrics**
   - **Single Sensitivity VECTORIZED - enforce metrics**

산출물: `bundle_single_*.zip`, `sweep_vec_bundle_enforced_*.zip`
